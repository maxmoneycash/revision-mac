# Monday · UI review

## Instructions

Review the supplied before and after screenshots. Apply only the requested changes. Keep unrelated behavior and styling intact. Ask about ambiguous feedback. Verify the result before reporting completion.

Coordinates below are normalized to the AFTER image (0–1), measured from its top-left corner. Regions identify the area to inspect; they are not proof of a defect. Compare the baseline for Restore notes. Images have not been automatically aligned.

## 1. Home

- Baseline: [before.png](01/before.png)
- Current: [after.png](01/after.png)
- Marked current image: [annotated.png](01/annotated.png)

### 1. Keep

Keep the new indigo focus card. The stronger contrast makes the primary action easier to find.

Region: x=0.0700, y=0.2500, width=0.8600, height=0.2200

### 2. Restore

Restore the spacing between task rows from the baseline. Keep the updated card styling above.

Region: x=0.0700, y=0.6800, width=0.8600, height=0.1300

## 2. Settings


No annotations recorded.

## 3. Onboarding


No annotations recorded.
